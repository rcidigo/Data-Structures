package sortA;


public interface SortAlgorithm {
	public void sort(double[] a, SortTimer t);

}
